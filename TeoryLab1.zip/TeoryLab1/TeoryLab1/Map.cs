﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TeoryLab1 {

    internal class Map {

        public const int distance = 30;

    }
}
